// NuGet package required: System.Windows.Forms.DataVisualization
using System.Windows.Forms.DataVisualization.Charting;

namespace WinFormsAppSchool
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // ── Tab pages ────────────────────────────────────────────────
            tabControl1    = new TabControl();
            tabInvoer      = new TabPage();
            tabOverzicht   = new TabPage();
            tabGrafiek     = new TabPage();

            // ── Invoer tab ───────────────────────────────────────────────
            lblNaam        = new Label();
            lblLeeftijd    = new Label();
            lblGewicht     = new Label();
            lblLengte      = new Label();
            lblFruit       = new Label();
            lblSport       = new Label();
            txtNaam        = new TextBox();
            nudLeeftijd    = new NumericUpDown();
            nudGewicht     = new NumericUpDown();
            nudLengte      = new NumericUpDown();
            nudFruit       = new NumericUpDown();
            nudSport       = new NumericUpDown();
            btnOpslaan     = new Button();
            btnLaden       = new Button();

            // ── Overzicht tab ────────────────────────────────────────────
            lblOverzichtInfo = new Label();
            dgvGezondheid    = new DataGridView();
            btnVerwijder     = new Button();
            btnBijwerken     = new Button();
            btnExportExcel   = new Button();
            btnExportPdf     = new Button();

            // ── Grafieken tab ────────────────────────────────────────────
            chFruit        = new Chart();
            chSport        = new Chart();
            chGrafiek2     = new Chart();
            btnMaakGrafiek = new Button();

            // ── Shared ───────────────────────────────────────────────────
            btnAfsluit     = new Button();

            tabControl1.SuspendLayout();
            tabInvoer.SuspendLayout();
            tabOverzicht.SuspendLayout();
            tabGrafiek.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGezondheid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chFruit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chSport).BeginInit();
            ((System.ComponentModel.ISupportInitialize)chGrafiek2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudLeeftijd).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudGewicht).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudLengte).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudFruit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudSport).BeginInit();
            SuspendLayout();

            // ════════════════════════════════════════════════════════════
            // tabControl1
            // ════════════════════════════════════════════════════════════
            tabControl1.Controls.Add(tabInvoer);
            tabControl1.Controls.Add(tabOverzicht);
            tabControl1.Controls.Add(tabGrafiek);
            tabControl1.Location      = new Point(10, 10);
            tabControl1.Name          = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size          = new Size(960, 500);
            tabControl1.TabIndex      = 0;
            tabControl1.SelectedIndexChanged += TabControl1_SelectedIndexChanged;
            tabControl1.Selecting            += TabControl1_Selecting;

            // ════════════════════════════════════════════════════════════
            // tabInvoer  (952 x 467)
            // Block: lw=160 + gap=10 + iw=180 = 350 wide, 6*40+39=279 tall
            // px = (952-350)/2 = 301, py = (467-279)/2 = 94
            // ════════════════════════════════════════════════════════════
            int lw  = 160, iw = 180, gap = 10, rh = 40;
            int pw  = lw + gap + iw;           // 350
            int px  = (952 - pw) / 2;          // 301
            int py  = (467 - (6 * rh + 39)) / 2; // 94
            int ix  = px + lw + gap;           // 471

            tabInvoer.BackColor = Color.White;
            tabInvoer.Controls.Add(lblNaam);
            tabInvoer.Controls.Add(lblLeeftijd);
            tabInvoer.Controls.Add(lblGewicht);
            tabInvoer.Controls.Add(lblLengte);
            tabInvoer.Controls.Add(lblFruit);
            tabInvoer.Controls.Add(lblSport);
            tabInvoer.Controls.Add(txtNaam);
            tabInvoer.Controls.Add(nudLeeftijd);
            tabInvoer.Controls.Add(nudGewicht);
            tabInvoer.Controls.Add(nudLengte);
            tabInvoer.Controls.Add(nudFruit);
            tabInvoer.Controls.Add(nudSport);
            tabInvoer.Controls.Add(btnOpslaan);
            tabInvoer.Controls.Add(btnLaden);
            tabInvoer.Location = new Point(4, 29);
            tabInvoer.Name     = "tabInvoer";
            tabInvoer.Size     = new Size(952, 467);
            tabInvoer.TabIndex = 0;
            tabInvoer.Text     = "Invoer";

            SetLabel(lblNaam,     "Naam:",             px, py + 0 * rh + 5, 0, lw);
            SetLabel(lblLeeftijd, "Leeftijd:",         px, py + 1 * rh + 5, 1, lw);
            SetLabel(lblGewicht,  "Gewicht (kg):",     px, py + 2 * rh + 5, 2, lw);
            SetLabel(lblLengte,   "Lengte (cm):",      px, py + 3 * rh + 5, 3, lw);
            SetLabel(lblFruit,    "Fruit per dag:",    px, py + 4 * rh + 5, 4, lw);
            SetLabel(lblSport,    "Sporten per week:", px, py + 5 * rh + 5, 5, lw);

            txtNaam.Location  = new Point(ix, py + 0 * rh + 3);
            txtNaam.Size      = new Size(iw, 27);
            txtNaam.TabIndex  = 6;
            txtNaam.KeyPress += TxtNaam_KeyPress;

            nudLeeftijd.Location = new Point(ix, py + 1 * rh + 3);
            nudLeeftijd.Size     = new Size(iw, 27);
            nudLeeftijd.TabIndex = 7;
            nudLeeftijd.Minimum  = 0;
            nudLeeftijd.Maximum  = 120;
            nudLeeftijd.Value    = 18;

            nudGewicht.Location      = new Point(ix, py + 2 * rh + 3);
            nudGewicht.Size          = new Size(iw, 27);
            nudGewicht.TabIndex      = 8;
            nudGewicht.Minimum       = 0;
            nudGewicht.Maximum       = 300;
            nudGewicht.DecimalPlaces = 1;
            nudGewicht.Increment     = 0.5m;
            nudGewicht.Value         = 70;

            nudLengte.Location = new Point(ix, py + 3 * rh + 3);
            nudLengte.Size     = new Size(iw, 27);
            nudLengte.TabIndex = 9;
            nudLengte.Minimum  = 0;
            nudLengte.Maximum  = 250;
            nudLengte.Value    = 170;

            nudFruit.Location = new Point(ix, py + 4 * rh + 3);
            nudFruit.Size     = new Size(iw, 27);
            nudFruit.TabIndex = 10;
            nudFruit.Minimum  = 0;
            nudFruit.Maximum  = 20;

            nudSport.Location = new Point(ix, py + 5 * rh + 3);
            nudSport.Size     = new Size(iw, 27);
            nudSport.TabIndex = 11;
            nudSport.Minimum  = 0;
            nudSport.Maximum  = 14;

            int btnY     = py + 6 * rh + 10;
            int btnTotal = 80 + 10 + 80;
            int btnX     = px + (pw - btnTotal) / 2;

            btnOpslaan.Location = new Point(btnX, btnY);
            btnOpslaan.Name     = "btnOpslaan";
            btnOpslaan.Size     = new Size(80, 29);
            btnOpslaan.TabIndex = 12;
            btnOpslaan.Text     = "Opslaan";
            btnOpslaan.Click   += BtnOpslaan_Click;

            btnLaden.Location = new Point(btnX + 90, btnY);
            btnLaden.Name     = "btnLaden";
            btnLaden.Size     = new Size(80, 29);
            btnLaden.TabIndex = 13;
            btnLaden.Text     = "Laden";
            btnLaden.Click   += BtnLaden_Click;

            // ════════════════════════════════════════════════════════════
            // tabOverzicht  (952 x 467)
            // ════════════════════════════════════════════════════════════
            tabOverzicht.BackColor = Color.White;
            tabOverzicht.Controls.Add(lblOverzichtInfo);
            tabOverzicht.Controls.Add(dgvGezondheid);
            tabOverzicht.Controls.Add(btnVerwijder);
            tabOverzicht.Controls.Add(btnBijwerken);
            tabOverzicht.Controls.Add(btnExportExcel);
            tabOverzicht.Controls.Add(btnExportPdf);
            tabOverzicht.Location = new Point(4, 29);
            tabOverzicht.Name     = "tabOverzicht";
            tabOverzicht.Size     = new Size(952, 467);
            tabOverzicht.TabIndex = 1;
            tabOverzicht.Text     = "Overzicht";

            // Info label explaining how to edit
            lblOverzichtInfo.Location  = new Point(10, 408);
            lblOverzichtInfo.Size      = new Size(400, 34);
            lblOverzichtInfo.Name      = "lblOverzichtInfo";
            lblOverzichtInfo.Text      = "💡 Dubbelklik op een cel om te wijzigen, klik dan op 'Bijwerken'.";
            lblOverzichtInfo.ForeColor = Color.DimGray;
            lblOverzichtInfo.Font      = new System.Drawing.Font("Segoe UI", 9f, System.Drawing.FontStyle.Italic);
            lblOverzichtInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            dgvGezondheid.ColumnHeadersHeight = 29;
            dgvGezondheid.Location            = new Point(10, 10);
            dgvGezondheid.MultiSelect         = false;
            dgvGezondheid.Name                = "dgvGezondheid";
            dgvGezondheid.RowHeadersWidth     = 51;
            dgvGezondheid.SelectionMode       = DataGridViewSelectionMode.FullRowSelect;
            dgvGezondheid.Size                = new Size(920, 390);
            dgvGezondheid.TabIndex            = 0;
            dgvGezondheid.AllowUserToAddRows  = false;
            dgvGezondheid.EditMode            = DataGridViewEditMode.EditOnKeystrokeOrF2;
            dgvGezondheid.SelectionChanged   += DgvGezondheid_SelectionChanged;
            dgvGezondheid.DataBindingComplete += DgvGezondheid_DataBindingComplete;

            btnVerwijder.BackColor              = Color.LightCoral;
            btnVerwijder.Enabled                = false;
            btnVerwijder.Location               = new Point(420, 408);
            btnVerwijder.Name                   = "btnVerwijder";
            btnVerwijder.Size                   = new Size(120, 34);
            btnVerwijder.TabIndex               = 1;
            btnVerwijder.Text                   = "Verwijder rij";
            btnVerwijder.UseVisualStyleBackColor = false;
            btnVerwijder.Click                 += BtnVerwijder_Click;

            btnBijwerken.BackColor              = Color.FromArgb(198, 220, 255);
            btnBijwerken.Enabled                = false;
            btnBijwerken.Location               = new Point(550, 408);
            btnBijwerken.Name                   = "btnBijwerken";
            btnBijwerken.Size                   = new Size(120, 34);
            btnBijwerken.TabIndex               = 2;
            btnBijwerken.Text                   = "Bijwerken";
            btnBijwerken.UseVisualStyleBackColor = false;
            btnBijwerken.Click                 += BtnBijwerken_Click;

            btnExportExcel.BackColor              = Color.FromArgb(198, 239, 206);
            btnExportExcel.Location               = new Point(690, 408);
            btnExportExcel.Name                   = "btnExportExcel";
            btnExportExcel.Size                   = new Size(120, 34);
            btnExportExcel.TabIndex               = 3;
            btnExportExcel.Text                   = "Exporteer Excel";
            btnExportExcel.UseVisualStyleBackColor = false;
            btnExportExcel.Click                 += BtnExportExcel_Click;

            btnExportPdf.BackColor              = Color.FromArgb(255, 199, 195);
            btnExportPdf.Location               = new Point(820, 408);
            btnExportPdf.Name                   = "btnExportPdf";
            btnExportPdf.Size                   = new Size(110, 34);
            btnExportPdf.TabIndex               = 4;
            btnExportPdf.Text                   = "Exporteer PDF";
            btnExportPdf.UseVisualStyleBackColor = false;
            btnExportPdf.Click                 += BtnExportPdf_Click;

            // ════════════════════════════════════════════════════════════
            // tabGrafiek  (952 x 467)
            // 3 charts centered: 3*290 + 2*20 = 910, x0 = (952-910)/2 = 21
            // ════════════════════════════════════════════════════════════
            int cw = 290, ch = 400, cgap = 20, cy = 48;
            int chartTotalW = 3 * cw + 2 * cgap;
            int cx0 = (952 - chartTotalW) / 2;

            tabGrafiek.BackColor = Color.White;
            tabGrafiek.Controls.Add(btnMaakGrafiek);
            tabGrafiek.Controls.Add(chFruit);
            tabGrafiek.Controls.Add(chSport);
            tabGrafiek.Controls.Add(chGrafiek2);
            tabGrafiek.Location = new Point(4, 29);
            tabGrafiek.Name     = "tabGrafiek";
            tabGrafiek.Size     = new Size(952, 467);
            tabGrafiek.TabIndex = 2;
            tabGrafiek.Text     = "Grafieken";

            btnMaakGrafiek.Location = new Point((952 - 130) / 2, 8);
            btnMaakGrafiek.Name     = "btnMaakGrafiek";
            btnMaakGrafiek.Size     = new Size(130, 30);
            btnMaakGrafiek.TabIndex = 0;
            btnMaakGrafiek.Text     = "🔄 Vernieuwen";
            btnMaakGrafiek.Click   += BtnMaakGrafiek_Click;

            chFruit.Location  = new Point(cx0, cy);
            chFruit.Name      = "chFruit";
            chFruit.Size      = new Size(cw, ch);
            chFruit.TabIndex  = 1;

            chSport.Location  = new Point(cx0 + cw + cgap, cy);
            chSport.Name      = "chSport";
            chSport.Size      = new Size(cw, ch);
            chSport.TabIndex  = 2;

            chGrafiek2.Location = new Point(cx0 + 2 * (cw + cgap), cy);
            chGrafiek2.Name     = "chGrafiek2";
            chGrafiek2.Size     = new Size(cw, ch);
            chGrafiek2.TabIndex = 3;

            // ════════════════════════════════════════════════════════════
            // Afsluit button & Form
            // ════════════════════════════════════════════════════════════
            btnAfsluit.BackColor              = Color.LightGray;
            btnAfsluit.Location               = new Point(850, 520);
            btnAfsluit.Name                   = "btnAfsluit";
            btnAfsluit.Size                   = new Size(100, 38);
            btnAfsluit.TabIndex               = 1;
            btnAfsluit.Text                   = "Afsluit";
            btnAfsluit.UseVisualStyleBackColor = false;
            btnAfsluit.Click                 += BtnAfsluit_Click;

            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode       = AutoScaleMode.Font;
            ClientSize          = new Size(980, 580);
            Controls.Add(tabControl1);
            Controls.Add(btnAfsluit);
            Name        = "Form1";
            Text        = "GezondheidApp";
            MaximizeBox = false;
            MinimizeBox = false;
            Resize     += Form1_Resize;

            tabControl1.ResumeLayout(false);
            tabInvoer.ResumeLayout(false);
            tabInvoer.PerformLayout();
            tabOverzicht.ResumeLayout(false);
            tabGrafiek.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvGezondheid).EndInit();
            ((System.ComponentModel.ISupportInitialize)chFruit).EndInit();
            ((System.ComponentModel.ISupportInitialize)chSport).EndInit();
            ((System.ComponentModel.ISupportInitialize)chGrafiek2).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudLeeftijd).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudGewicht).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudLengte).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudFruit).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudSport).EndInit();
            ResumeLayout(false);
        }

        // ── Helpers ──────────────────────────────────────────────────────
        private static void SetLabel(Label lbl, string text, int x, int y, int tabIdx, int width)
        {
            lbl.Location  = new Point(x, y);
            lbl.Size      = new Size(width, 23);
            lbl.TabIndex  = tabIdx;
            lbl.Text      = text;
            lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
        }

        // ── Designer fields ──────────────────────────────────────────────
        private System.Windows.Forms.TabControl  tabControl1;
        private System.Windows.Forms.TabPage     tabInvoer;
        private System.Windows.Forms.TabPage     tabOverzicht;
        private System.Windows.Forms.TabPage     tabGrafiek;

        private System.Windows.Forms.Label       lblNaam;
        private System.Windows.Forms.Label       lblLeeftijd;
        private System.Windows.Forms.Label       lblGewicht;
        private System.Windows.Forms.Label       lblLengte;
        private System.Windows.Forms.Label       lblFruit;
        private System.Windows.Forms.Label       lblSport;
        private System.Windows.Forms.Label       lblOverzichtInfo;

        private System.Windows.Forms.TextBox         txtNaam;
        private System.Windows.Forms.NumericUpDown   nudLeeftijd;
        private System.Windows.Forms.NumericUpDown   nudGewicht;
        private System.Windows.Forms.NumericUpDown   nudLengte;
        private System.Windows.Forms.NumericUpDown   nudFruit;
        private System.Windows.Forms.NumericUpDown   nudSport;

        private System.Windows.Forms.Button      btnOpslaan;
        private System.Windows.Forms.Button      btnLaden;
        private System.Windows.Forms.Button      btnAfsluit;
        private System.Windows.Forms.Button      btnVerwijder;
        private System.Windows.Forms.Button      btnBijwerken;
        private System.Windows.Forms.Button      btnExportExcel;
        private System.Windows.Forms.Button      btnExportPdf;
        private System.Windows.Forms.Button      btnMaakGrafiek;

        private System.Windows.Forms.DataGridView dgvGezondheid;

        private Chart chFruit;
        private Chart chSport;
        private Chart chGrafiek2;
    }
}
