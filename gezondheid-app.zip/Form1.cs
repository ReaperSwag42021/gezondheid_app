using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using ClosedXML.Excel;
using iText.Kernel.Colors;
using iText.Kernel.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Properties;
using iText.IO.Font.Constants;
using Microsoft.Data.SqlClient;

namespace WinFormsAppSchool
{
    public partial class Form1 : Form
    {
        private readonly string connectionString =
            @"Data Source=.\SQLEXPRESS;Initial Catalog=GezondheidDB;Trusted_Connection=True;TrustServerCertificate=True";

        public Form1()
        {
            InitializeComponent();
            UpdateGrafiekTabState();
        }

        // ═══════════════════════════════════════════════════════════════
        // OPDRACHT 1 – Afsluit button
        // ═══════════════════════════════════════════════════════════════
        private void BtnAfsluit_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.Red;

            int offsetX = -40;
            int offsetY =  75;

            System.Drawing.Rectangle screen = Screen.FromControl(this).Bounds;
            System.Windows.Forms.Cursor.Position = new System.Drawing.Point(
                screen.Left + screen.Width  / 2 + offsetX,
                screen.Top  + screen.Height / 2 + offsetY);

            DialogResult result = MessageBox.Show(
                "Weet je het zeker?", "Afsluiten",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1);

            if (result == DialogResult.Yes)
                Application.Exit();
            else
                this.BackColor = SystemColors.Control;
        }

        // ═══════════════════════════════════════════════════════════════
        // OPDRACHT 2 – TabControl
        // ═══════════════════════════════════════════════════════════════
        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected = tabControl1.SelectedTab;
            if (selected == null) return;

            if (selected == tabOverzicht)
                LaadData();
            else if (selected == tabGrafiek)
            {
                if (chFruit == null || chSport == null || chGrafiek2 == null) return;
                MaakGrafiekFruit();
                MaakGrafiekSport();
                MaakGrafiek2();
            }
        }

        // Prevents navigating to a disabled tab
        private void TabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (e.TabPage != null && !e.TabPage.Enabled)
                e.Cancel = true;
        }

        // ═══════════════════════════════════════════════════════════════
        // OPDRACHT 3 – Resize warning
        // ═══════════════════════════════════════════════════════════════
        private bool _scaryShowing = false;

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (_scaryShowing) return;
            _scaryShowing = true;

            System.Media.SystemSounds.Hand.Play();

            using Form overlay = new()
            {
                FormBorderStyle = FormBorderStyle.None,
                WindowState     = FormWindowState.Maximized,
                TopMost         = true,
                BackColor       = System.Drawing.Color.Black,
                Opacity         = 0.92,
                StartPosition   = FormStartPosition.Manual,
                Bounds          = Screen.FromControl(this).Bounds
            };

            Label lbl = new()
            {
                Text      = "😱 STOP! 😱",
                Font      = new System.Drawing.Font("Arial", 120, System.Drawing.FontStyle.Bold),
                ForeColor = System.Drawing.Color.Red,
                BackColor = System.Drawing.Color.Black,
                Dock      = DockStyle.Fill,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            };

            Label hint = new()
            {
                Text      = "Klik om te sluiten...",
                ForeColor = System.Drawing.Color.White,
                BackColor = System.Drawing.Color.Transparent,
                Font      = new System.Drawing.Font("Arial", 14),
                Dock      = DockStyle.Bottom,
                Height    = 40,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            };

            overlay.Controls.Add(lbl);
            overlay.Controls.Add(hint);
            overlay.KeyPreview = true;
            overlay.KeyDown   += (s, ke) => { if (ke.KeyCode == Keys.Escape) overlay.Close(); };
            overlay.Click     += (s, _)  => overlay.Close();
            lbl.Click         += (s, _)  => overlay.Close();

            overlay.ShowDialog(this);
            _scaryShowing = false;
        }

        // ═══════════════════════════════════════════════════════════════
        // DataGridView – selection
        // ═══════════════════════════════════════════════════════════════
        private void DgvGezondheid_SelectionChanged(object sender, EventArgs e)
        {
            bool hasSelection    = dgvGezondheid.SelectedRows.Count > 0;
            btnVerwijder.Enabled = hasSelection;
            btnBijwerken.Enabled = hasSelection;
        }

        // Make Id column read-only and disable column reordering after data loads
        private void DgvGezondheid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            if (dgvGezondheid.Columns.Contains("Id"))
                dgvGezondheid.Columns["Id"].ReadOnly = true;
        }

        // ═══════════════════════════════════════════════════════════════
        // UPDATE – edit cells in grid, click Bijwerken to save
        // ═══════════════════════════════════════════════════════════════
        private void BtnBijwerken_Click(object sender, EventArgs e)
        {
            if (dgvGezondheid.SelectedRows.Count == 0) return;

            // Commit any in-progress cell edit first
            dgvGezondheid.EndEdit();

            var row = dgvGezondheid.SelectedRows[0];

            try
            {
                int    id      = Convert.ToInt32(row.Cells["Id"].Value);
                string naam    = row.Cells["Naam"].Value?.ToString() ?? "";
                int    leeft   = Convert.ToInt32(row.Cells["Leeftijd"].Value);
                double gewicht = Convert.ToDouble(row.Cells["Gewicht"].Value);
                double lengte  = Convert.ToDouble(row.Cells["Lengte"].Value);
                int    fruit   = Convert.ToInt32(row.Cells["aantal_fruit_per_dag"].Value);
                int    sport   = Convert.ToInt32(row.Cells["aantal_sport_per_week"].Value);

                if (string.IsNullOrWhiteSpace(naam))
                {
                    MessageBox.Show("Naam mag niet leeg zijn!", "Validatie",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                const string sql =
                    "UPDATE gezondheid SET Naam=@Naam, Leeftijd=@Leeftijd, Gewicht=@Gewicht, " +
                    "Lengte=@Lengte, aantal_fruit_per_dag=@Fruit, aantal_sport_per_week=@Sport " +
                    "WHERE Id=@Id";

                using SqlCommand cmd = new(sql, cnn);
                cmd.Parameters.AddWithValue("@Naam",     naam);
                cmd.Parameters.AddWithValue("@Leeftijd", leeft);
                cmd.Parameters.AddWithValue("@Gewicht",  gewicht);
                cmd.Parameters.AddWithValue("@Lengte",   lengte);
                cmd.Parameters.AddWithValue("@Fruit",    fruit);
                cmd.Parameters.AddWithValue("@Sport",    sport);
                cmd.Parameters.AddWithValue("@Id",       id);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Gegevens bijgewerkt!", "Bijgewerkt",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LaadData();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // ═══════════════════════════════════════════════════════════════
        // DELETE
        // ═══════════════════════════════════════════════════════════════
        private void BtnVerwijder_Click(object sender, EventArgs e)
        {
            if (dgvGezondheid.SelectedRows.Count == 0) return;

            int id = Convert.ToInt32(dgvGezondheid.SelectedRows[0].Cells["Id"].Value);

            if (MessageBox.Show("Weet je zeker dat je deze rij wilt verwijderen?",
                "Verwijderen", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                using SqlCommand cmd = new("DELETE FROM gezondheid WHERE Id = @Id", cnn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();

                ResetIdentityAlsLeeg();
                LaadData();
                UpdateGrafiekTabState();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void ResetIdentityAlsLeeg()
        {
            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                string sql = @"IF NOT EXISTS (SELECT 1 FROM gezondheid)
                                   DBCC CHECKIDENT ('gezondheid', RESEED, 0)";
                using SqlCommand cmd = new(sql, cnn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // ═══════════════════════════════════════════════════════════════
        // KeyPress validator – Naam only accepts letters
        // ═══════════════════════════════════════════════════════════════
        private void TxtNaam_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
                e.Handled = true;
        }

        // ═══════════════════════════════════════════════════════════════
        // CREATE (Invoer tab)
        // ═══════════════════════════════════════════════════════════════
        private void BtnOpslaan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNaam.Text))
            {
                MessageBox.Show("Vul alle velden in voor je opslaat!",
                    "Leeg veld", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                const string sql =
                    "INSERT INTO gezondheid (Naam, Leeftijd, Gewicht, Lengte, " +
                    "aantal_fruit_per_dag, aantal_sport_per_week) " +
                    "VALUES (@Naam, @Leeftijd, @Gewicht, @Lengte, @Fruit, @Sport)";

                using SqlCommand cmd = new(sql, cnn);
                cmd.Parameters.AddWithValue("@Naam",     txtNaam.Text);
                cmd.Parameters.AddWithValue("@Leeftijd", (int)nudLeeftijd.Value);
                cmd.Parameters.AddWithValue("@Gewicht",  (double)nudGewicht.Value);
                cmd.Parameters.AddWithValue("@Lengte",   (double)nudLengte.Value);
                cmd.Parameters.AddWithValue("@Fruit",    (int)nudFruit.Value);
                cmd.Parameters.AddWithValue("@Sport",    (int)nudSport.Value);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Gegevens opgeslagen!");
                txtNaam.Clear();
                nudLeeftijd.Value = 18;
                nudGewicht.Value  = 70;
                nudLengte.Value   = 170;
                nudFruit.Value    = 0;
                nudSport.Value    = 0;
                LaadData();
                UpdateGrafiekTabState();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnLaden_Click(object sender, EventArgs e) => LaadData();

        // ═══════════════════════════════════════════════════════════════
        // READ
        // ═══════════════════════════════════════════════════════════════
        private void LaadData()
        {
            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                SqlDataAdapter adapter = new("SELECT * FROM gezondheid", cnn);
                DataTable dt = new();
                adapter.Fill(dt);
                dgvGezondheid.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // ═══════════════════════════════════════════════════════════════
        // Grafieken tab state
        // ═══════════════════════════════════════════════════════════════
        private void UpdateGrafiekTabState()
        {
            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                using SqlCommand cmd = new("SELECT COUNT(*) FROM gezondheid", cnn);
                int count = (int)cmd.ExecuteScalar();
                tabGrafiek.Enabled = count > 0;

                if (!tabGrafiek.Enabled && tabControl1.SelectedTab == tabGrafiek)
                    tabControl1.SelectedTab = tabInvoer;
            }
            catch { tabGrafiek.Enabled = false; }
        }

        // ═══════════════════════════════════════════════════════════════
        // WEEK 4 – GRAFIEKEN
        // ═══════════════════════════════════════════════════════════════
        private void BtnMaakGrafiek_Click(object sender, EventArgs e)
        {
            try
            {
                MaakGrafiekFruit();
                MaakGrafiekSport();
                MaakGrafiek2();
            }
            catch (Exception ex) { MessageBox.Show($"Fout:\n{ex.Message}", "Grafiek Fout"); }
        }

        private void MaakGrafiekFruit()
        {
            chFruit.Series.Clear();
            chFruit.Titles.Clear();
            chFruit.Legends.Clear();
            chFruit.ChartAreas.Clear();
            chFruit.ChartAreas.Add(new ChartArea("Default"));

            (int totAantal, int totFruit, _) = HaalCijfersOp();

            chFruit.Series.Add("series");
            chFruit.Series[0].ChartType = SeriesChartType.Pie;
            chFruit.Titles.Add("Onderzoek fruit");

            int rest = Math.Max(0, (totAantal * 4) - totFruit);
            chFruit.Series[0].Points.AddXY("fruit eten",    totFruit);
            chFruit.Series[0].Points.AddXY("maximaal fruit", rest);
            chFruit.Series[0].Points[0].Color = System.Drawing.Color.Green;
            chFruit.Series[0].Points[1].Color = System.Drawing.Color.Salmon;
        }

        private void MaakGrafiekSport()
        {
            chSport.Series.Clear();
            chSport.Titles.Clear();
            chSport.Legends.Clear();
            chSport.ChartAreas.Clear();
            chSport.ChartAreas.Add(new ChartArea("Default"));

            (int totAantal, _, int totSport) = HaalCijfersOp();

            chSport.Series.Add("series");
            chSport.Series[0].ChartType = SeriesChartType.Pie;
            chSport.Titles.Add("Onderzoek sport");

            int rest = Math.Max(0, (totAantal * 7) - totSport);
            chSport.Series[0].Points.AddXY("aantal sporten",   totSport);
            chSport.Series[0].Points.AddXY("sporten maximaal", rest);
            chSport.Series[0].Points[0].Color = System.Drawing.Color.Green;
            chSport.Series[0].Points[1].Color = System.Drawing.Color.Salmon;
        }

        private void MaakGrafiek2()
        {
            chGrafiek2.Series.Clear();
            chGrafiek2.Titles.Clear();
            chGrafiek2.Legends.Clear();
            chGrafiek2.ChartAreas.Clear();
            chGrafiek2.ChartAreas.Add(new ChartArea("Default"));

            (int totAantal, int totFruit, int totSport) = HaalCijfersOp();
            int maxFruit  = totAantal * 4;
            int maxSport  = totAantal * 7;

            chGrafiek2.Series.Add("aantal");
            chGrafiek2.Series.Add("maximum");
            chGrafiek2.Series[0].ChartType = SeriesChartType.StackedColumn;
            chGrafiek2.Series[1].ChartType = SeriesChartType.StackedColumn;
            chGrafiek2.Titles.Add("Onderzoek gezondheid");

            chGrafiek2.Series[0].Points.Add(new DataPoint(0, totFruit));
            chGrafiek2.Series[0].Points.Add(new DataPoint(1, totSport));
            chGrafiek2.Series[1].Points.Add(new DataPoint(0, Math.Max(0, maxFruit  - totFruit)));
            chGrafiek2.Series[1].Points.Add(new DataPoint(1, Math.Max(0, maxSport  - totSport)));

            chGrafiek2.Series[0].Points[0].AxisLabel = "Fruit";
            chGrafiek2.Series[0].Points[1].AxisLabel = "Sporten";

            chGrafiek2.Legends.Add(new Legend("Legenda"));
            chGrafiek2.Series[0].Legend = "Legenda";
            chGrafiek2.Series[1].Legend = "Legenda";
        }

        private (int totAantal, int totFruit, int totSport) HaalCijfersOp()
        {
            int totAantal = 0, totFruit = 0, totSport = 0;
            try
            {
                using SqlConnection cnn = new(connectionString);
                cnn.Open();
                const string sql =
                    "SELECT COUNT(*) AS tot, " +
                    "ISNULL(SUM(aantal_fruit_per_dag),0)  AS fruit, " +
                    "ISNULL(SUM(aantal_sport_per_week),0) AS sport " +
                    "FROM gezondheid";
                using SqlCommand cmd = new(sql, cnn);
                using SqlDataReader r = cmd.ExecuteReader();
                if (r.Read())
                {
                    totAantal = Convert.ToInt32(r["tot"]);
                    totFruit  = Convert.ToInt32(r["fruit"]);
                    totSport  = Convert.ToInt32(r["sport"]);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            return (totAantal, totFruit, totSport);
        }

        // ═══════════════════════════════════════════════════════════════
        // WEEK 5 – EXCEL EXPORT (ClosedXML)
        // ═══════════════════════════════════════════════════════════════
        private void BtnExportExcel_Click(object sender, EventArgs e)
        {
            using SaveFileDialog sfd = new()
            {
                Filter   = "Excel bestand|*.xlsx",
                FileName = "gezondheid.xlsx"
            };
            if (sfd.ShowDialog() != DialogResult.OK) return;

            try
            {
                using var wb = new XLWorkbook();
                var ws = wb.Worksheets.Add("Data");

                for (int c = 0; c < dgvGezondheid.Columns.Count; c++)
                    ws.Cell(1, c + 1).Value = dgvGezondheid.Columns[c].HeaderText;

                for (int r = 0; r < dgvGezondheid.Rows.Count; r++)
                    for (int c = 0; c < dgvGezondheid.Columns.Count; c++)
                        ws.Cell(r + 2, c + 1).Value =
                            dgvGezondheid.Rows[r].Cells[c].Value?.ToString() ?? "";

                ws.Columns().AdjustToContents();
                wb.SaveAs(sfd.FileName);
                MessageBox.Show($"Excel bestand opgeslagen:\n{sfd.FileName}",
                    "Exporteren", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // ═══════════════════════════════════════════════════════════════
        // WEEK 5 – PDF EXPORT (itext7)
        // ═══════════════════════════════════════════════════════════════
        private void BtnExportPdf_Click(object sender, EventArgs e)
        {
            using SaveFileDialog sfd = new()
            {
                Filter   = "PDF bestand|*.pdf",
                FileName = "gezondheid.pdf"
            };
            if (sfd.ShowDialog() != DialogResult.OK) return;

            try
            {
                using var writer   = new PdfWriter(sfd.FileName);
                using var pdfDoc   = new PdfDocument(writer);
                using var document = new Document(pdfDoc, iText.Kernel.Geom.PageSize.A4);
                document.SetMargins(25, 15, 25, 15);

                PdfFont boldFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA_BOLD);
                PdfFont bodyFont = PdfFontFactory.CreateFont(StandardFonts.HELVETICA);

                document.Add(new iText.Layout.Element.Paragraph("GezondheidApp – Overzicht deelnemers")
                    .SetFont(boldFont).SetFontSize(16));
                document.Add(new iText.Layout.Element.Paragraph($"Datum: {DateTime.Now:dd-MM-yyyy HH:mm}")
                    .SetFont(bodyFont).SetFontSize(10));
                document.Add(new iText.Layout.Element.Paragraph("\n"));

                int colCount = dgvGezondheid.Columns.Count;
                var tabel = new iText.Layout.Element.Table(colCount)
                    .SetWidth(UnitValue.CreatePercentValue(100))
                    .SetMarginTop(10);

                for (int c = 0; c < colCount; c++)
                    tabel.AddHeaderCell(
                        new iText.Layout.Element.Cell().Add(
                            new iText.Layout.Element.Paragraph(dgvGezondheid.Columns[c].HeaderText)
                                .SetFont(boldFont).SetFontSize(10))
                        .SetBackgroundColor(new DeviceRgb(198, 224, 180)).SetPadding(5));

                for (int r = 0; r < dgvGezondheid.Rows.Count; r++)
                {
                    DeviceRgb bg = r % 2 == 0
                        ? new DeviceRgb(255, 255, 255)
                        : new DeviceRgb(242, 242, 242);
                    for (int c = 0; c < colCount; c++)
                    {
                        string val = dgvGezondheid.Rows[r].Cells[c].Value?.ToString() ?? "";
                        tabel.AddCell(
                            new iText.Layout.Element.Cell().Add(
                                new iText.Layout.Element.Paragraph(val).SetFont(bodyFont).SetFontSize(10))
                            .SetBackgroundColor(bg).SetPadding(4));
                    }
                }

                document.Add(tabel);

                (int totAantal, int totFruit, int totSport) = HaalCijfersOp();
                document.Add(new iText.Layout.Element.Paragraph("\n"));
                document.Add(new iText.Layout.Element.Paragraph($"Totaal deelnemers : {totAantal}").SetFont(bodyFont).SetFontSize(10));
                document.Add(new iText.Layout.Element.Paragraph($"Totaal fruit/dag  : {totFruit}" ).SetFont(bodyFont).SetFontSize(10));
                document.Add(new iText.Layout.Element.Paragraph($"Totaal sport/week : {totSport}" ).SetFont(bodyFont).SetFontSize(10));

                MessageBox.Show($"PDF opgeslagen:\n{sfd.FileName}",
                    "Exporteren", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Type: {ex.GetType().FullName}\n\nMessage: {ex.Message}\n\nInner: {ex.InnerException?.Message}",
                    "PDF Fout", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
