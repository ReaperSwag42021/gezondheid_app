# GezondheidApp – C# WinForms Portfolio Project

A complete CRUD application built as a 5-week school assignment, demonstrating
Windows Forms development with SQL Server, charts, and document exports.

## Features

### Invoer tab (Create)
- Centered form with NumericUpDown controls for type-safe numeric input
- Naam validated to letters only via KeyPress event
- Saves new records to SQL Server

### Overzicht tab (Read / Update / Delete)
- DataGridView showing all records from the database
- **Update**: double-click a cell to edit, then click "Bijwerken"
- **Delete**: select a row and click "Verwijder rij"
- **Export Excel**: saves entire grid to .xlsx via ClosedXML
- **Export PDF**: generates A4 PDF with header, striped table, and summary stats via itext7
- Id column is locked (read-only) to prevent breakage

### Grafieken tab (Visualizations)
- **Pie chart**: fruit consumption vs maximum
- **Pie chart**: sport sessions vs maximum
- **Stacked column chart**: fruit + sport side-by-side
- Auto-generated when tab is opened
- Tab is disabled when database is empty
- 🔄 Vernieuwen button to manually refresh

### Events (Week 3)
- **Afsluit button**: turns form red, repositions cursor over "Ja", confirms exit
- **Tab change**: auto-reloads data when switching to Overzicht, auto-draws charts on Grafieken
- **Form resize**: fullscreen scary overlay with system sound (resize is also blocked via disabled maximize/minimize buttons)

## Setup

### 1. Database
Create a database called `GezondheidDB` in SQL Server Express and run:
```sql
CREATE TABLE gezondheid (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Naam VARCHAR(50),
    Leeftijd INT,
    Gewicht FLOAT,
    Lengte FLOAT,
    aantal_fruit_per_dag INT NOT NULL DEFAULT 0,
    aantal_sport_per_week INT NOT NULL DEFAULT 0
);
```

If you already have the older `gezondheid` table, run `migrate_gezondheid.sql` to add the new columns.

### 2. NuGet packages
Install via Package Manager Console:
```
Install-Package ClosedXML
Install-Package HIC.System.Windows.Forms.DataVisualization
Install-Package itext7
Install-Package itext7.bouncy-castle-adapter
Install-Package Microsoft.Data.SqlClient
```

### 3. Project file (.csproj)
Targets `net10.0-windows` with WinForms enabled. Full PackageReference list:
- ClosedXML 0.105.0
- HIC.System.Windows.Forms.DataVisualization 1.0.1
- itext7 9.5.0
- itext7.bouncy-castle-adapter (latest)
- Microsoft.Data.SqlClient 6.1.4
- Newtonsoft.Json 13.0.4

## Architecture notes

- `Form1.cs`: all event handlers and business logic
- `Form1.Designer.cs`: UI layout, fully code-based (no .resx dependencies)
- Connection string uses `Data Source=.\SQLEXPRESS;Initial Catalog=GezondheidDB;Trusted_Connection=True;TrustServerCertificate=True`
- All SQL queries use parameterized commands to prevent injection
- Charts use `System.Windows.Forms.DataVisualization.Charting` (ported library for .NET 10)
