-- Run this script once against your GezondheidDB to add the new columns
ALTER TABLE gezondheid
    ADD aantal_fruit_per_dag  INT NOT NULL DEFAULT 0,
        aantal_sport_per_week INT NOT NULL DEFAULT 0;
